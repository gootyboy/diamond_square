"""
### __main__.py

Outputs links to all of the sample code files.
"""

def main():
    print("Welcome to diamond-square:")
    print("A package which can draw terrains and interactive terrains using the Diamond Square Algorithm in pgzero and pygame.")
    print("Also include 3d terrains in panda3d. Uses C for fast rendering.")
    print("Here are all of the sample codes:")
    print("\n")
    print("TERRAIN EXAMPLES")
    print("")
    print("Drawing terrain in pgzero: https://github.com/gootyboy/diamond_square/blob/main/sample_codes/pgzero_terrain.py")
    print("Drawing terrain in pygame: https://github.com/gootyboy/diamond_square/blob/main/sample_codes/pygame_terrain.py")
    print("Drawing 3D terrain in panda3d: https://github.com/gootyboy/diamond_square/blob/main/sample_codes/panda3d_terrain3d.py")
    print("")
    print("INTERACTIVE TERRAIN EXAMPLES")
    print("")
    print("Drawing interactive terrain in pgzero: https://github.com/gootyboy/diamond_square/blob/main/sample_codes/pgzero_interactive_terrain.py")
    print("Drawing interactive terrain in pygame: https://github.com/gootyboy/diamond_square/blob/main/sample_codes/pygame_interactive_terrain.py")
    print("")
    print("OTHER EXAMPLES")
    print("")
    print("Saving terrain as image: https://github.com/gootyboy/diamond_square/blob/main/sample_codes/save_terrain.py")
    print("Creating Custom Biomes: https://github.com/gootyboy/diamond_square/blob/main/sample_codes/custom_biome.py")
    print("")

if __name__ == "__main__":
    main()
