"""
C to Python wrapper for the core diamond square algorithm.
"""

import os
import ctypes
import math

class Array2D(ctypes.Structure):
    """
    A Structure for a struct in the diamond.c file.

    Fields
    ------
    **rows**: c_size_t

        The amount of rows for the array.
    **cols**: c_size_t

        The amount of columns for the array.
    **data**: POINTER(POINTER(c_double))

        The data of the array.
    """
    _fields_ = [
        ("rows", ctypes.c_size_t),
        ("cols", ctypes.c_size_t),
        ("data", ctypes.POINTER(ctypes.POINTER(ctypes.c_double)))
    ]

_file = 'core_algorithm_lib.so'
_path = os.path.join(*(os.path.split(__file__)[:-1] + (_file,)))
_mod = ctypes.cdll.LoadLibrary(_path)

_mod.core_diamond_square.restype = Array2D
_mod.core_diamond_square.argtypes = [ctypes.c_int, ctypes.c_float]

_mod.custom_diamond_square.restype = Array2D
_mod.custom_diamond_square.argtypes = [ctypes.c_int, ctypes.c_float, ctypes.c_float, ctypes.c_float, ctypes.c_float, ctypes.c_float]

_mod.free_array2d.restype = None
_mod.free_array2d.argtypes = [Array2D]

def core_diamond_square(size: int, roughness: float) -> list[list[float]]:
    """
    Returns a height map using the Diamond Square Algorithm.
    
    Parameters
    ----------
    **size**: int
        The size of the height map. Must be integer greater than 1.
    **roughness**: float
        Controls the amount of randomness that is added to each height value.

    Returns
    -------
    **Height Map**: list[list[float]]
        The height map generated using the Diamond Square Algorithm.
    """
    c_heights = _mod.core_diamond_square(size, roughness)
    heights = [
        [c_heights.data[y][x] for x in range(size)]
        for y in range(size)
    ]
    if c_heights.data:
        _mod.free_array2d(c_heights)

    return heights

def custom_diamond_square(size: int, roughness: float, topleft: float, topright: float, bottomleft: float, bottomright: float) -> list[list[float]]:
    """
    Returns a height map using the Diamond Square Algorithm.

    Parameters
    ----------
    **size**: int
        The size of the height map. Must be integer greater than 1.
    **roughness**: float
        Controls the amount of randomness that is added to each height value.

    Returns
    -------
    **Height Map**: list[list[float]]
        The height map generated using the Diamond Square Algorithm.
    """
    c_heights = _mod.custom_diamond_square(size, roughness, topleft, topright, bottomleft, bottomright)
    heights = [
        [c_heights.data[y][x] for x in range(size)]
        for y in range(size)
    ]
    if c_heights.data:
        _mod.free_array2d(c_heights)

    return heights
